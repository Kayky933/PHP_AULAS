<?php

$conexao = mysqli_connect('localhost', 'root',  '', '5-crud');
?>