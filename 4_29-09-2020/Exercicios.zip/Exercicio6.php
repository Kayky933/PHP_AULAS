<!doctype html>
<html>

<head>
    <meta charser="UTF-8">
    <title> Exercício 6 29/09/2020</title>
</head>

<body>
    <h1>Exercício 6</h1>

    <form method="POST">
        <label>Número 1:</label><br>
        <input type="text" name="v1"><br>

        <label>Número 2:</label><br>
        <input type="text" name="v2"><br>
        <input name="executar" type="submit" value="Executar">
    </form>

    <?php
    if ($_POST) {

        $v1 = $_POST['v1'];
        $v2 = $_POST['v2'];
      
        echo "Valor 1 é:$v1 e valor 2 é $v2";
        echo "<br>O valor absoluto de $v2 é". abs($v2);
        echo "<br>A raiz de $v1 é".sqrt($v1);
        echo "<br>A raiz de $v2 é".sqrt($v2);
        echo "<br>O valor de $v1 é ". round($v1);
        echo "<br>O valor de $v2 é ". round($v2);
        echo "<br>A parte inteira de $v1 é ". intval($v1);
        echo "<br>A parte inteira de $v2 é ". intval($v2);
        echo "<br>O valor de $v1 em moeda é:R$". number_format($v1,2,",",".");
        echo "<br>O valor de $v2 em moeda é:R$". number_format($v2, 2,",",".");
        echo "<br>O valor de $v1<sup>$v2</sup> e ". pow($v1, $v2);
      
       
    }
    ?>
</body>

</html>